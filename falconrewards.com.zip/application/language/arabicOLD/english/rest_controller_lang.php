<?php

	$lang['I\'m a man'] = "I'm a man";

?>